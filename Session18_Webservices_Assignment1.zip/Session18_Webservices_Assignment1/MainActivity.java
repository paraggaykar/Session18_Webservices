package com.newweatherwebservices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;



public class MainActivity extends Activity {

    //URL to get JSON Array
    private static String url = "http://api.openweathermap.org/data/2.5/weather?q=London,uk&appid=d7b900681c37193223281142bd919019";

    //JSON Node Names
    private static final String TAG_WEATHER = "weather";
    private static final String TAG_TEMP = "temp";
    private static final String TAG_PRESSURE = "pressure";
    private static final String TAG_HUMIDITY = "humidity";

    JSONArray user = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        // Creating new JSON Parser
        ServiceHandler jParser = new ServiceHandler();

        // Getting JSON from URL
        String json = jParser.makeServiceCall(url, ServiceHandler.GET);
        try {
            JSONObject jsonObj = new JSONObject(json);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            // Getting JSON Array
            user = user.getJSONArray(Integer.parseInt(TAG_WEATHER));
            JSONObject c = user.getJSONObject(0);

            // Storing  JSON item in a Variable
            String temp = c.getString(TAG_TEMP);
            String pre = c.getString(TAG_PRESSURE);
            String hum = c.getString(TAG_HUMIDITY);

            //Importing TextView
            final TextView temp1 = (TextView)findViewById(R.id.temperature);
            final TextView pre1 = (TextView)findViewById(R.id.pressure);
            final TextView hum1 = (TextView)findViewById(R.id.humidity);

            //Set JSON Data in TextView
            temp1.setText(temp);
            pre1.setText(pre);
            hum1.setText(hum);

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

}